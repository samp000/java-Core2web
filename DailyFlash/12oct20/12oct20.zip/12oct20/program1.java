
	class StringDemo1 {

		public static void main(String args[]) {

			String str1 = "Sandesh";

			String str2 = new String("Marathe");

			System.out.println(str1 +" " +str2);
		}
	}
