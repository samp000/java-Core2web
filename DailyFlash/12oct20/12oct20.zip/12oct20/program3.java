
	class StringDemo3 {

		public static void main(String[] args) {

			String str1 = "Sandesh" ;	//this is "string literal" it is stored in SCP(String Constant Pool) as referance object 


			String str2 = new String("Marathe"); /*this is reference String object is stored on heap and then check in SCP string like this                                                               i.e. in this case is "Marathe" if string like this not found it stores string in scp as un							      refference object is */
		}
	}
