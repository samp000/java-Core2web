
	class StringDemo4 {

		public static void main(String[] args) {

			String s1 = "String1";
			String s2 = new String("String2");

			s2 = "Swap String2";
			s1 = new String("Swap String1");

			// you can store string literal in String object and vice versa
		}
	}
