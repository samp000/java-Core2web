
	import java.util.*;

	class StringDemo5 {

		public static void main(String[] args) {

			Scanner sc = new Scanner(System.in);
			System.out.print("Enter string: ");
			String str1 = sc.nextLine();
			String str2 =new String("String2");

			System.out.println(str1+"\'"+str2);
		}
	}
