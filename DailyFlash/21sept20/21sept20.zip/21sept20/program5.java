
	class AddNum {

		public static void main(String args[]) {

			int no1 = Integer.parseInt(args[0]);
			int no2 = Integer.parseInt(args[1]);

			System.out.println("Sum of "+no1 +" and " +no2 +" is " +(no1+no2));
		}
	}
