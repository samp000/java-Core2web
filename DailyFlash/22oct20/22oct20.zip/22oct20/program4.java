 import java.util.*;

       class StringCase {

                public static void main(String args[]) {

                        Scanner sc = new Scanner(System.in);

                        System.out.print("Enter String1:");
                        String str1 = sc.nextLine();
                        System.out.print("Enter String2:");
                        String str2 = sc.nextLine();

			System.out.println(str1.toUpperCase() +" " +str2.toLowerCase());
		}
       }

