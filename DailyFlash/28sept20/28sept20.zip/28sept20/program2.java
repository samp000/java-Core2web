
	import java.util.*;
	class Name {

		public static void main(String args[]) {

			Scanner sc = new Scanner(System.in);

		       	System.out.print("String1: ");
			String String1 = sc.nextLine();

		       	System.out.print("String2: ");
			String String2 = sc.nextLine();

		       	System.out.print("Result: " +String1 +" " +String2 +"\n");
		}
	}
