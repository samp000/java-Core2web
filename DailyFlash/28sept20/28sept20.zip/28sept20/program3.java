
	import java.util.*;

	class Email {

		public static void main(String args[]) {

			Scanner sc = new Scanner(System.in);

		       	System.out.print("Enter string Id : ");
			String strid = sc.next();

			System.out.print("Enter numerical Id : ");
			String numid = sc.next();

			System.out.println(strid +numid +"@gmail.com");
		}
	}
