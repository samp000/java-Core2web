
	class Indx {

		public static void main(String args[]) {

			int[] my_array = { 25,14,56,15,36,56,77,18,29,49};

			for(int i =0 ; i<my_array.length ; i++ )  {

				if(my_array[i] == 25)
					System.out.println("Index position of 25 : "+i);
				if(my_array[i] == 77)
					System.out.println("Index position of 77 : "+i);
			}
		}
	}
